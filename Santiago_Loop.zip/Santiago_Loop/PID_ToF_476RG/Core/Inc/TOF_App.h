/*
 * TOF_App.h
 *
 *  Created on: Jun 27, 2023
 *      Author: E1441590
 */

#ifndef INC_TOF_APP_H_
#define INC_TOF_APP_H_

#ifdef __cplusplus
 extern "C" {
#endif

 /* Includes ------------------------------------------------------------------*/

 /* Exported defines ----------------------------------------------------------*/

 /* Exported functions --------------------------------------------------------*/
 void MX_TOF_Init(void);
 long MX_TOF_Process(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_TOF_APP_H_ */
